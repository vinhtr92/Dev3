DROP TABLE IF EXISTS `#__jsn_pagebuilder3_config`;
DROP TABLE IF EXISTS `#__jsn_pagebuilder3_messages`;
